
# Handoff : Registre des Mariages Religieux

## Vue d'ensemble
Application permettant aux imams de plusieurs mosquées d'enregistrer les mariages religieux (nikah) qu'ils célèbrent, et de vérifier si une personne est déjà mariée religieusement avant une nouvelle union. Objectif : combler l'absence de registre centralisé pour les mariages religieux (contrairement aux mariages civils).

## À propos des fichiers de design
Le fichier fourni (`Registre Mariages Religieux.dc.html`) est une **référence de design HTML** — un prototype montrant l'apparence et le comportement voulus, pas du code de production à copier tel quel. La tâche consiste à **recréer ce design dans l'environnement technique cible** (React, Vue, backend + base de données réelle, etc.) en utilisant les patterns déjà établis dans ce codebase — ou, si aucun environnement n'existe encore, à choisir le framework le plus adapté (recommandé : une stack web classique avec une vraie base de données, car la donnée doit persister et être partagée entre plusieurs imams/mosquées).

**Important** : dans le prototype, toutes les données (mariages, mosquées) sont stockées en mémoire (state React) et se réinitialisent au rechargement. En production, il faut un vrai backend + base de données pour que les mariages enregistrés par un imam soient visibles par tous les autres imams.

## Fidélité
**Haute fidélité (hifi)** pour la structure d'écran, la navigation, les champs de formulaire et la logique métier (calcul de statut, alertes de conflit). Les couleurs/typographie sont un système cohérent mais peuvent être adaptées à la charte du client.

## Écrans / Vues

### 1. Tableau de bord (`view: 'dashboard'`)
- Titre "Tableau de bord" (serif, 32px, semi-bold)
- 4 cartes statistiques en grille responsive (auto-fit, min 180px) : Mariages enregistrés, Unions actives, Divorces enregistrés, Mosquées partenaires
- Boutons d'action : "+ Nouveau mariage" (primaire), "Vérifier une personne" (secondaire)
- Liste des 5 mariages les plus récents (nom époux & épouse, date, lieu, imam, badge de statut)

### 2. Vérifier une personne (`view: 'recherche'`)
- Champ de recherche unique (prénom et/ou nom, recherche floue insensible à la casse)
- Recherche active à partir de 2 caractères
- Résultats : cartes avec nom complet, badge de statut (Marié(e) / Divorcé(e) / Veuf(ve) / Célibataire) et détail textuel (conjoint, date du mariage, mosquée, imam, ou date de fin d'union)
- **Logique clé** : une personne peut apparaître comme époux OU épouse dans différents mariages ; le statut est calculé à partir de TOUS ses mariages enregistrés (union active > dernière union terminée > célibataire)

### 3. Nouveau mariage (`view: 'nouveau-mariage'`)
- Formulaire en 3 sections : Époux (prénom, nom, date de naissance), Épouse (idem), Cérémonie (date, lieu, mosquée → l'imam est déduit automatiquement de la mosquée choisie)
- **Vérification de conflit en temps réel** : dès que prénom+nom d'un époux/épouse correspondent à une union active existante, une bannière d'avertissement orange apparaît ("⚠ [Nom] est déjà enregistré(e) comme marié(e) depuis le [date]"). Ceci est informatif — n'empêche pas l'enregistrement (l'imam reste décisionnaire ; la polygamie masculine n'est pas bloquée techniquement).
- Bouton "Enregistrer le mariage" désactivé tant que les champs obligatoires ne sont pas remplis
- Message de succès + bouton "Enregistrer un autre" après soumission

### 4. Nouveau divorce / veuvage (`view: 'nouveau-divorce'`)
- Sélection d'une union active parmi une liste déroulante (label : "Prénom Nom & Prénom Nom — date (mosquée)")
- Choix du type : Divorce / Veuvage (boutons toggle)
- Date de fin d'union
- Soumission met à jour l'enregistrement du mariage (statut → terminé, type, date de fin)

### 5. Mosquées & imams (`view: 'mosquees'`)
- Cartes listant chaque mosquée : nom, ville, imam, nombre de mariages enregistrés
- Formulaire d'ajout d'une nouvelle mosquée (nom, ville, imam)

## Modèle de données

```
Mosquée { id, nom, ville, imam }

Mariage {
  id,
  mari: { prenom, nom, naissance },
  epouse: { prenom, nom, naissance },
  date, lieu,
  mosqueeId, mosqueeNom, imam,
  statut: 'actif' | 'termine',
  typeFin: null | 'divorce' | 'veuvage',
  dateFin: string | null
}
```

**Recommandation forte pour la production** : identifier les personnes par un ID unique (pas seulement prénom+nom, qui peut créer des collisions/homonymes) — envisager une pièce d'identité, date de naissance + lieu de naissance comme clé de désambiguïsation, avec un flux de résolution manuel par l'imam en cas d'homonymie.

## Interactions & comportement
- Navigation par barre latérale (5 items), pas de rechargement de page
- Responsive : sous ~860px de largeur, la barre latérale passe d'une colonne verticale (260px fixe) à une barre horizontale en haut, avec navigation qui wrap
- Aucune animation/transition complexe — état géré par simple re-render
- Pas de validation de format (email, téléphone) car ces champs ne sont pas utilisés dans ce prototype

## Design tokens

**Typographie**
- Titres : "Source Serif 4" (Google Fonts), 600, tailles 32px (H1), 19-21px (H2/logo)
- Corps/UI : "IBM Plex Sans", 400/500/600, tailles 12-15px

**Couleurs (OKLCH)**
- Fond page : `oklch(98% 0.006 90)` (blanc cassé chaud)
- Cartes/surfaces : `oklch(100% 0.002 90)`
- Bordures : `oklch(88% 0.006 90)`
- Texte principal : `oklch(20% 0.01 90)`
- Texte secondaire : `oklch(48% 0.01 90)`
- Barre latérale : fond `oklch(24% 0.025 250)`, texte `oklch(92% 0.01 250)`
- Accent primaire (boutons, nav actif) : `oklch(38% 0.07 200)` — personnalisable (variantes vert `oklch(35% 0.07 150)`, indigo `oklch(35% 0.08 260)`, terracotta `oklch(38% 0.07 30)`)
- Badge "Marié(e)" : fond `oklch(94% 0.03 150)`, texte `oklch(32% 0.09 150)` (vert)
- Badge "Divorcé(e)" : fond `oklch(94% 0.03 30)`, texte `oklch(38% 0.09 30)` (terracotta)
- Badge "Veuf(ve)" : fond `oklch(93% 0.01 260)`, texte `oklch(40% 0.03 260)` (gris-bleu)
- Badge "Célibataire" : fond `oklch(93% 0.006 90)`, texte `oklch(48% 0.01 90)` (gris neutre)
- Bannière d'avertissement (conflit) : fond `oklch(95% 0.04 60)`, texte `oklch(35% 0.09 50)` (ambre)

**Rayons / espacements**
- Rayon de bordure standard : 6-8px
- Cartes : padding 20-24px, gap 14-16px
- Boutons : padding 12px 22px, rayon 6px

## Assets
Aucun asset image — uniquement Google Fonts (Source Serif 4, IBM Plex Sans).

## Fichiers
- `Registre Mariages Religieux.dc.html` — prototype complet (structure, styles, logique métier en JS) à consulter comme référence de comportement et de calcul de statut.
